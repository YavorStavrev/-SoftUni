document.getElementById('submit').addEventListener('click', getWeather);

async function getWeather() {
    const location = document.getElementById('location').value;
    const forecastDiv = document.getElementById('forecast');
    const currentDiv = document.getElementById('current');
    const upcomingDiv = document.getElementById('upcoming');

    // Clear previous forecast
    currentDiv.innerHTML = '<div class="label">Current conditions</div>';
    upcomingDiv.innerHTML = '<div class="label">Three-day forecast</div>';
    forecastDiv.style.display = 'none';

    try {
        // Get location code
        const locationsResponse = await fetch('http://localhost:3030/jsonstore/forecaster/locations');
        if (!locationsResponse.ok) throw new Error('Error fetching locations');
        const locations = await locationsResponse.json();
        const locationObj = locations.find(loc => loc.name.toLowerCase() === location.toLowerCase());

        if (!locationObj) throw new Error('Location not found');

        const locationCode = locationObj.code;

        // Get current weather
        const currentResponse = await fetch(`http://localhost:3030/jsonstore/forecaster/today/${locationCode}`);
        if (!currentResponse.ok) throw new Error('Error fetching current weather');
        const currentWeather = await currentResponse.json();

        // Get 3-day forecast
        const upcomingResponse = await fetch(`http://localhost:3030/jsonstore/forecaster/upcoming/${locationCode}`);
        if (!upcomingResponse.ok) throw new Error('Error fetching upcoming weather');
        const upcomingWeather = await upcomingResponse.json();

        // Display current weather
        currentDiv.appendChild(createWeatherElement(currentWeather, 'current'));

        // Display 3-day forecast
        upcomingWeather.forecast.forEach(day => {
            upcomingDiv.appendChild(createWeatherElement(day, 'upcoming'));
        });

        forecastDiv.style.display = 'block';

    } catch (error) {
        forecastDiv.style.display = 'block';
        currentDiv.innerHTML = 'Error';
        upcomingDiv.innerHTML = '';
        console.error(error);
    }
}

function createWeatherElement(weather, type) {
    const weatherElement = document.createElement('div');
    if (type === 'current') {
        weatherElement.className = 'forecasts';
        weatherElement.innerHTML = `
            <span class="condition symbol">${getWeatherSymbol(weather.forecast.condition)}</span>
            <span class="condition">
                <span class="forecast-data">${weather.name}</span>
                <span class="forecast-data">${weather.forecast.low}°/${weather.forecast.high}°</span>
                <span class="forecast-data">${weather.forecast.condition}</span>
            </span>
        `;
    } else {
        weatherElement.className = 'forecast-info';
        weatherElement.innerHTML = `
            <span class="upcoming">
                <span class="symbol">${getWeatherSymbol(weather.condition)}</span>
                <span class="forecast-data">${weather.low}°/${weather.high}°</span>
                <span class="forecast-data">${weather.condition}</span>
            </span>
        `;
    }
    return weatherElement;
}

function getWeatherSymbol(condition) {
    switch (condition) {
        case 'Sunny': return '&#x2600;'; // ☀
        case 'Partly sunny': return '&#x26C5;'; // ⛅
        case 'Overcast': return '&#x2601;'; // ☁
        case 'Rain': return '&#x2614;'; // ☂
        default: return '';
    }
}
