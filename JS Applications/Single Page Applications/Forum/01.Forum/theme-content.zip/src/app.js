document.addEventListener('DOMContentLoaded', () => {
    // Select elements
    const topicContainer = document.querySelector('.topic-container');
    const form = document.querySelector('form');
    const topicNameInput = document.getElementById('topicName');
    const usernameInput = document.getElementById('username');
    const postTextInput = document.getElementById('postText');
    const cancelButton = document.querySelector('.cancel');
    const postButton = document.querySelector('.public');

    // Fetch and render existing topics
    fetch('http://localhost:3030/jsonstore/collections/myboard/posts')
        .then(response => response.json())
        .then(data => {
            Object.values(data).forEach(topic => {
                renderTopic(topic);
            });
        });

    // Function to render a topic on the homepage
    function renderTopic(topic) {
        const topicElement = document.createElement('div');
        topicElement.classList.add('topic-item');
        topicElement.innerHTML = `
            <h3>${topic.title}</h3>
            <p>Posted by: ${topic.username}</p>
            <p>${topic.content}</p>
        `;
        topicElement.addEventListener('click', () => {
            window.location.href = `topic.html?id=${topic._id}`;
        });
        topicContainer.appendChild(topicElement);
    }

    // Event listener for creating a new topic
    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const title = topicNameInput.value.trim();
        const username = usernameInput.value.trim();
        const content = postTextInput.value.trim();

        if (title && username && content) {
            const newTopic = {
                title,
                username,
                content,
                _id: Date.now().toString() // Generate unique ID
            };

            fetch('http://localhost:3030/jsonstore/collections/myboard/posts', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newTopic)
            })
            .then(response => response.json())
            .then(data => {
                renderTopic(data);
                // Clear input fields
                form.reset();
            })
            .catch(error => console.error('Error:', error));
        } else {
            alert('Please fill in all fields!');
        }
    });

    // Event listener for cancel button
    cancelButton.addEventListener('click', (event) => {
        event.preventDefault();
        form.reset();
    });
});
