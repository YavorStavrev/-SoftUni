document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const topicId = urlParams.get('id');

    const commentSection = document.querySelector('.comment');
    const commentForm = document.querySelector('form');
    const usernameInput = document.getElementById('username');
    const commentInput = document.getElementById('comment');

    // Fetch and render the selected topic
    fetch(`http://localhost:3030/jsonstore/collections/myboard/posts/${topicId}`)
        .then(response => response.json())
        .then(topic => {
            document.querySelector('.theme-title h2').textContent = topic.title;
        });

    // Fetch and render all comments for the selected topic
    fetch(`http://localhost:3030/jsonstore/collections/myboard/comments`)
        .then(response => response.json())
        .then(data => {
            const comments = Object.values(data).filter(comment => comment.topicId === topicId);
            comments.forEach(renderComment);
        });

    // Function to render a comment
    function renderComment(comment) {
        const commentElement = document.createElement('div');
        commentElement.classList.add('comment-item');
        commentElement.innerHTML = `
            <p><strong>${comment.username}:</strong> ${comment.content}</p>
        `;
        commentSection.appendChild(commentElement);
    }

    // Event listener for posting a comment
    commentForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const username = usernameInput.value.trim();
        const content = commentInput.value.trim();

        if (username && content) {
            const newComment = {
                topicId,
                username,
                content
            };

            fetch('http://localhost:3030/jsonstore/collections/myboard/comments', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newComment)
            })
            .then(response => response.json())
            .then(data => {
                renderComment(data);
                commentForm.reset();
            })
            .catch(error => console.error('Error:', error));
        } else {
            alert('Please fill in all fields!');
        }
    });
});
